NATURAL GALLERY — 3D PROTOTYPE

Open index.html through an HTTPS static host. It uses Three.js from jsDelivr.

Features:
- Real-time WebGL 3D gallery
- 12 rooms arranged around a central natural court
- Room 1 open; Rooms 2–12 marked Coming Soon
- Walk-through WASD/arrow controls and mouse/touch look
- Warm wood, stone, trees, rocks and gallery lighting
- Placeholder photograph, poem and song fields
- Ready for later content integration

Next stage: replace placeholders with your actual photographs, poems and Bandzoogle-hosted audio, then deploy the gallery and embed it on your Bandzoogle landing page.
